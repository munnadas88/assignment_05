<section id="basic-forms">

    <div class="container">

        <form action="" method="POST">

               <div class="col-md-8 m-auto">
                   <div class="form-group">
                       <input type="text" value="" name="user_name" class="form-control" placeholder="Enter your name">
                   </div>
               </div>
            <div class="col-md-8 m-auto">
                <div class="form-group">
                    <input type="email" value="" name="user_email" class="form-control" placeholder="Enter your email">
                </div>
            </div>
                <div class="col-md-8 m-auto">
                    <div class="form-group">
                       <input type="submit" class="btn btn btn-outline-primary form-control" name="submit" value="Try to Submit">
                    </div>
                </div>


        </form>
    </div>
</section>