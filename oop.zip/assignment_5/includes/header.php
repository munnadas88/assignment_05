<?php ob_start(); ?>
<?php include ("functions.php"); ?>
<!doctype html>
<html lang="en">
<head>
   
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Form</title>
    <!-- Linking Css-->
    <link rel="stylesheet" href="css/style.css"/>
    <!-- favicon  -->
<!--    <link rel="icon" href="images/crypt.png"/>-->
    <!-- Link Fontawesome -->
<!--    <link rel="stylesheet" href="fontawesome/css/all.min.css"/>-->
    <!--Bulma Css Frameworks  -->
    <link rel="stylesheet" href="bootstrap-css/css/bootstrap.css"/>
    <link rel="stylesheet" href="bootstrap-css/js/bootstrap.js"/>
<!--    Google Fonts Conect -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700;800&display=swap" rel="stylesheet">

</head>
<body>
