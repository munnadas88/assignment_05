<section id="footer-part">

    <div class="container">
        <div class="footer-content">
           <p>
               Copyright © 2023 Munna Das. All rights reserved.
           </p>
            <p>
                Follow Me on <a href="#"> Facebook</a>
                Follow Me on <a href="#"> Instagram</a>
            </p>
        </div>
    </div>

</section>
<link rel="stylesheet" href="fontawesome/js/all.min.js"/>
<!-- Link Js -->
<script src="js/script.js"></script>
</body>
</html>